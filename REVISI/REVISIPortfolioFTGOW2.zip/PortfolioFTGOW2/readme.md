
1. Please to make sure tag <script> dibuat dibawah <section> form. 
2. perhatikan lagi tanda kurung buka dan tutup pada function editForm() dan saveForm();
3. <!-- <form method="#" action="#"> </form> -->  di uncomment supaya pada saat melakukan pergantian data , data diupdate ke profil.
4. Silahkan dilanjutkan kembali